const enum CloseCode {
    ServerFull = 4000,
    ProtocolError = 4001,
    BadRequest = 4002
}

export default CloseCode;
